package com.capgemini.demo.provider;

public interface MessageProvider{
	
	String getMessage();
}