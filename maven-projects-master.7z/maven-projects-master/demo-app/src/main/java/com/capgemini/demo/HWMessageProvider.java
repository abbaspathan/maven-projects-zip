package com.capgemini.demo.provider;

public class HWMessageProvider implements MessageProvider{

	public String getMessage(){
		return "Hello World...!!";
	}
}