package com.capgemini.demo.provider;

public class GMMessageProvider implements MessageProvider{

	public String getMessage(){
		return "Good Morning...!!";
	}
}